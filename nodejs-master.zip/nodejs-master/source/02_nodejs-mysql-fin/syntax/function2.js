console.log(Math.round(1.6)); //2
console.log(Math.round(1.4)); //1

function sum(first, second) { // parameter
  return first+second;
}

console.log(sum(2,4)); // argument

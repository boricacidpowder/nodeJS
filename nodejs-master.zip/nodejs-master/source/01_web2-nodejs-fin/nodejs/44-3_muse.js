var part = require('./mpart.js');
console.log(part);

console.log(1 + 1);
console.log('1' + '1');

a = 1;	// ← a 변수 선언 후 숫자 1 대입
console.log(a);
a = 2;	// ← a 변수에 숫자 2 대입
console.log(a);
// 1 = 2;	// ← 오류 발생!

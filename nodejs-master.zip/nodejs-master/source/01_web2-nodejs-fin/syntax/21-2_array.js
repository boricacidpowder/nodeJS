var arr = ['A', 'B', 'C', 'D'];
console.log(arr);

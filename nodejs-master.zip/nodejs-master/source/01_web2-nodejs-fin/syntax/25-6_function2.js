function sum(first, second) {
    return first + second;
}

console.log(sum(2, 4));

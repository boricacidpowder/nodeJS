console.log('A');
console.log('B');
if(true) {
    console.log('C1');
} else {
    console.log('C2');
}
console.log('D');

function a() {
    console.log('A');
}
a();

var arr = ['A', 'B', 'C', 'D'];

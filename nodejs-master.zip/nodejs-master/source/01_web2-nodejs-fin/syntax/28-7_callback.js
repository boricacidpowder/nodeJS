var a = function () {
    console.log('A');
}

function slowfunc() {
}

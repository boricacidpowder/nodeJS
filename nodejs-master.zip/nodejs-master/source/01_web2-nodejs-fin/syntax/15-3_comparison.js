console.log(1 == 1);  	// true
console.log(1 == 2);  	// false
console.log(1 < 2);  	// true
console.log(1 > 2);  	// false
console.log(1 === 1);  	// true
console.log(1 === 2);  	// false
